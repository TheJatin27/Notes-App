package com.note.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cse_sem6_subjects extends AppCompatActivity {

    private Button DAA;
    private Button CC;
    private Button IMED;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cse_sem6_subjects);



        //Development of Android Applications

        DAA=findViewById(R.id.button68);
        DAA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.youtube.com");
            }
        });

        //Cloud Computing

        CC=findViewById(R.id.button69);
        CC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Industrial Management and Entrepreneurship Development

        IMED=findViewById(R.id.button70);
        IMED.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

    }

    private void gotoUrl(String s) {

        Uri uri= Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}


