package com.note.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cse_sem3_subjects extends AppCompatActivity {

    private Button maths3;
    private Button IWT;
    private Button ES;
    private Button DCCN;
    private Button C;
    private Button de;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cse_sem3_subjects);

        //Applied Maths III

        maths3=findViewById(R.id.button51);
        maths3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Internet and Web Technology

        IWT=findViewById(R.id.button52);
        IWT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Environmental Studies

        ES=findViewById(R.id.button53);
        ES.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });



        //Data Communication and Computer Networks

        DCCN=findViewById(R.id.button54);
        DCCN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });


        //C

        C=findViewById(R.id.button55);
        C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Digital Electronic

        de=findViewById(R.id.button56);
        de.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });




    }

    private void gotoUrl(String s) {

        Uri uri= Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}

