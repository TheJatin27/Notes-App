package com.note.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cse_sem4_subjects extends AppCompatActivity {

    private Button CS2;
    private Button DMS;
    private Button JAVA;
    private Button OS;
    private Button ECDM;
    private Button EC;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cse_sem4_subjects);


        //Comunication Skill II

        CS2=findViewById(R.id.button57);
        CS2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Database Management System

        DMS=findViewById(R.id.button58);
        DMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Object Oriented Programming Using Java

        JAVA=findViewById(R.id.button59);
        JAVA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });



        //Operating System

        OS=findViewById(R.id.button60);
        OS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });


        //E-Commerce and Digital Marketing

        ECDM=findViewById(R.id.button61);
        ECDM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });

        //Energy Conservation

        EC=findViewById(R.id.button62);
        EC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("xyz");
            }
        });




    }

    private void gotoUrl(String s) {

        Uri uri= Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}
