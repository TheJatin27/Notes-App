package com.note.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class civil_sem1_subjects extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civil_sem1_subjects);
    }
}