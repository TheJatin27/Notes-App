package com.note.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cse_sem1_subjects extends AppCompatActivity {

    private Button maths;
    private Button phy;
    private Button chem;
    private Button fcit;
    private Button CS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cse_sem1_subjects);
        //maths

        maths=findViewById(R.id.button42);
        maths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/drive/folders/1-1lu4FRIeUCsD-_QlVpuH8RI5GBRL5GM?usp=sharing");
            }
        });

        //Physics

        phy=findViewById(R.id.button43);
        phy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/drive/folders/1-1lu4FRIeUCsD-_QlVpuH8RI5GBRL5GM?usp=sharing");
            }
        });


        //Chemistry

        chem=findViewById(R.id.button44);
        chem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/drive/folders/1-1lu4FRIeUCsD-_QlVpuH8RI5GBRL5GM?usp=sharing");
            }
        });

        //FCIT

        fcit=findViewById(R.id.button45);
        fcit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/drive/folders/1-1lu4FRIeUCsD-_QlVpuH8RI5GBRL5GM?usp=sharing");
            }
        });

        //CS-I

        CS=findViewById(R.id.buttonCS1);
        CS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/drive/folders/1-1lu4FRIeUCsD-_QlVpuH8RI5GBRL5GM?usp=sharing");
            }
        });


    }

    private void gotoUrl(String s) {

        Uri uri= Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));

    }
}