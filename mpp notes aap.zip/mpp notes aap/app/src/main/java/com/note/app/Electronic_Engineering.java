package com.note.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Electronic_Engineering extends AppCompatActivity {
    private Button sem1;
    private Button sem2;
    private Button sem3;
    private Button sem4;
    private Button sem5;
    private Button sem6;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electronic_engineering);

        //Semester 1

        sem1=findViewById(R.id.button36);
        sem1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Electronic_Engineering.this,eonics_sem1_subjects.class);
                startActivity(intent);
            }
        });

        //Semester 2

        sem2=findViewById(R.id.button37);
        sem2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Electronic_Engineering.this,eonics_sem2_subjects.class);
                startActivity(intent);
            }
        });

        //Semester 3

        sem3=findViewById(R.id.button38);
        sem3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Electronic_Engineering.this,eonics_sem3.class);
                startActivity(intent);
            }
        });


        //Semester 4

        sem4=findViewById(R.id.button39);
        sem4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Electronic_Engineering.this,eonics_sem4_subjects.class);
                startActivity(intent);
            }
        });


        //Semester 5

        sem5=findViewById(R.id.button40);
        sem5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Electronic_Engineering.this,eonics_sem5_subjects.class);
                startActivity(intent);
            }
        });


        //Semester 6

        sem6=findViewById(R.id.button41);
        sem6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Electronic_Engineering.this,eonics_sem6_subjects.class);
                startActivity(intent);
            }
        });



    }
}